const {Schema, model} = require('mongoose');

const NodeSchema = new Schema({
    title:{
        type: String,
        required:true
     },
     description: {
         type: String,
         required: true
     },
     cant: {
        type: Number,
        required: true
    },
     user: {
         type: String,
         required: true
     }
}, {
    timestamps:true
})

module.exports = model('Note', NodeSchema);