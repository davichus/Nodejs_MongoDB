const { Router } = require('express')
const router = Router()


const { renderNoteForm, 
        createNewNote, 
        renderNote, 
        renderEditForm, 
        updateNote, 
        deleteNote 
    } = require('../controllers/nodes.controller');

const { isAuthenticated } = require('../helpers/auth');

//new note
router.get('/notes/add', isAuthenticated, renderNoteForm);

router.post('/notes/new-note', isAuthenticated, createNewNote);

//Get All note
router.get('/notes', isAuthenticated, renderNote)

//Edit Notes
router.get('/notes/edit/:id', isAuthenticated, renderEditForm)

router.put('/notes/edit/:id', isAuthenticated, updateNote )

//delete
router.delete('/notes/delete/:id', isAuthenticated, deleteNote)

module.exports = router